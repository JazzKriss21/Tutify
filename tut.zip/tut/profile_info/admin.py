from django.contrib import admin

# Register your models here.

from profile_info.models import TutorProfile

admin.site.register(TutorProfile)
